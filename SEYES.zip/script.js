document.getElementById('generatePDFButton').addEventListener('click', generatePDF);

function generatePDF() {
    const { jsPDF } = window.jspdf;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();

    const squareSize = parseFloat(prompt("Entrez la taille des carrés (en mm) : ", "10"));
    const interlineSize = squareSize / 4; // Pour 3 lignes intérieures, diviser la taille du carré par 4
    const marginSize = 40; // 4 cm de marge

    // Définir les couleurs
    const marginColor = "#FF69B4"; // Rose pour la marge
    const darkLineColor = "#0000FF"; // Bleu foncé pour les lignes principales
    const lightLineColor = "#ADD8E6"; // Bleu clair pour les lignes intérieures

    // Dessiner la ligne de marge
    doc.setLineWidth(0.5); // Largeur de la ligne de marge
    doc.setDrawColor(marginColor);
    doc.line(marginSize, 10, marginSize, pageHeight - 10); // Ligne de marge à 40 mm du bord gauche

    // Dessiner les lignes verticales (à partir de la deuxième ligne)
    doc.setDrawColor(darkLineColor);
    doc.setLineWidth(0.2); // Largeur des lignes verticales
    for (let x = marginSize + squareSize; x < pageWidth - 10; x += squareSize) {
        doc.line(x, 10, x, pageHeight - 10); // Ligne verticale
    }

    // La position de la dernière ligne verticale
    const lastVerticalLineX = pageWidth - 10 - ((pageWidth - 10 - marginSize) % squareSize);

    // Dessiner les lignes horizontales
    for (let y = 10; y < pageHeight - 10; y += squareSize) {
        for (let j = 0; j < 4; j++) {
            const lineY = y + j * interlineSize;

            if (j < 3) {
                doc.setDrawColor(lightLineColor);
                doc.setLineWidth(0.1); // Largeur des lignes intérieures
                doc.line(10, lineY, lastVerticalLineX, lineY); // Lignes intérieures
            } else {
                doc.setDrawColor(darkLineColor);
                doc.setLineWidth(0.2); // Largeur des lignes principales
                doc.line(10, lineY, lastVerticalLineX, lineY); // Ligne principale
            }
        }
    }

    doc.save('quadrillage.pdf');
}
